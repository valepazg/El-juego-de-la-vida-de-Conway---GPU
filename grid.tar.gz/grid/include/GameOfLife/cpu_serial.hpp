int serial_simulation(string filename);
