int opencl_simulation(string filename, string mode);
